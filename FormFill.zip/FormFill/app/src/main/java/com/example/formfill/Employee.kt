package com.example.formfill

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "employee")
data class Employee(
    @PrimaryKey(autoGenerate=true)
    val id : Long,
    val name : String,
    val email : String,
    val gender : String,
    val streamch : String,
    val jobmode : String
)
