package com.example.formfill

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.room.Room
import kotlinx.android.synthetic.main.activity_fill_form.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FillForm : AppCompatActivity() {
    lateinit var database : EmployeeDatabase
    lateinit var streamch : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fill_form)

        spdropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, position: Int, Id: Long) {
                Toast.makeText(this@FillForm,"you selected ${adapterView?.getItemAtPosition(position).toString()}",
                    Toast.LENGTH_SHORT).show()
                streamch = adapterView?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }

        database = Room.databaseBuilder(applicationContext,
        EmployeeDatabase::class.java,
        "employeeDB").build()

        btnSubmit.setOnClickListener{

            val name :String = et_names.text.toString()
            val email:String  = et_email.text.toString()
            var gender = "null"
            lateinit var radioButton: RadioButton
            val mode = "fulltime"

            val selectedOption: Int = radioGroup!!.checkedRadioButtonId


            radioButton = findViewById(selectedOption)
            gender =   radioButton.text.toString()

            GlobalScope.launch {
                database.employeeDao().insertEmployee(Employee(0,name,email,gender,streamch,"Full Time"))


            }





        }


        }



    }
