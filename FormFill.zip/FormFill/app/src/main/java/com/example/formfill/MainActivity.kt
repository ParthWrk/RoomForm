package com.example.formfill

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.room.Room
import kotlinx.android.synthetic.main.activity_fill_form.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
//    lateinit var database : EmployeeDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        database = Room.databaseBuilder(applicationContext,
//            EmployeeDatabase::class.java,
//            "employeeDB").build()
//
//        GlobalScope.launch {
//            database.employeeDao().insertEmployee(Employee(0,"Parth","Parth@gmail.com","Male","Electrical and Electronics Engineering","Full Time"))
//        }

//


        btnGo.setOnClickListener{
            val intent = Intent(this,FillForm::class.java)
            startActivity(intent)
        }


    }
}